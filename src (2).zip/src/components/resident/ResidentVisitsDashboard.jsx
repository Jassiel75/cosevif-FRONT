"use client"

import { useState } from "react"
import VisitTable from "./visits/VisitTable"
import VisitForm from "./visits/VisitForm"

function ResidentVisitsDashboard() {
  const [visits, setVisits] = useState([])
  const [showForm, setShowForm] = useState(false)

  const loadVisits = () => {
    const token = localStorage.getItem("token")
    setLoading(true)

    axios
      .get("http://localhost:8080/resident/visits", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        setVisits(res.data)
        setLoading(false)
      })
      .catch((err) => {
        console.error("Error al obtener las visitas:", err)
        setError("Hubo un error al obtener las visitas.")
        setLoading(false)
      })
  }

  return (
    <div>
      <VisitTable
        visits={visits}
        onOpenForm={() => setShowForm(true)}
        onToggleStatus={handleToggleStatus}
        onView={handleView}
        onDelete={handleDeleteClick}
      />

      {showForm && <VisitForm onClose={() => setShowForm(false)} onSuccess={loadVisits} />}
    </div>
  )
}

export default ResidentVisitsDashboard
