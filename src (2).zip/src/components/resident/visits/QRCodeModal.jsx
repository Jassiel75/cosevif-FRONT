"use client"
import { useEffect, useState } from "react"
import { QRCodeCanvas } from "qrcode.react"
import "../../../styles/resident/visits/QRCodeModal.css"

function QRCodeModal({ visit, onClose }) {
  const [qrValue, setQrValue] = useState("")
  const [timeLeft, setTimeLeft] = useState("")

  // Agregar estas funciones al inicio del componente
  function formatDate(dateTimeStr) {
    if (!dateTimeStr) return "N/A"

    // Si la fecha viene en formato ISO 8601 (con T), convertirla a objeto Date
    // Si viene en formato YYYY-MM-DDThh:mm (del input), mantenerla como está
    let date
    if (dateTimeStr.includes("T")) {
      date = new Date(dateTimeStr)
    } else {
      // Dividir la fecha y hora
      const [datePart, timePart] = dateTimeStr.split(" ")
      date = new Date(`${datePart}T${timePart || "00:00"}`)
    }

    // Formatear fecha para México (día/mes/año)
    return date.toLocaleDateString("es-MX", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  function formatTime(dateTimeStr) {
    if (!dateTimeStr) return "N/A"

    // Si la fecha viene en formato ISO 8601 (con T), convertirla a objeto Date
    // Si viene en formato YYYY-MM-DDThh:mm (del input), mantenerla como está
    let date
    if (dateTimeStr.includes("T")) {
      date = new Date(dateTimeStr)
    } else {
      // Dividir la fecha y hora
      const [datePart, timePart] = dateTimeStr.split(" ")
      date = new Date(`${datePart}T${timePart || "00:00"}`)
    }

    // Formatear hora para México (hora:minutos)
    return date.toLocaleTimeString("es-MX", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  useEffect(() => {
    if (!visit) return

    // Crear un objeto con la información relevante de la visita
    const visitInfo = {
      id: visit.id,
      visitorName: visit.visitorName,
      dateTime: visit.dateTime,
      numPeople: visit.numPeople,
      password: visit.password,
      timestamp: new Date().toISOString(),
    }

    // Convertir a JSON y luego a string para el QR
    setQrValue(JSON.stringify(visitInfo))

    // Actualizar el tiempo restante cada segundo
    const interval = setInterval(() => {
      const visitDate = new Date(visit.dateTime)
      const now = new Date()
      const diffMs = visitDate.getTime() - now.getTime()

      if (diffMs <= 0) {
        setTimeLeft("¡Es hora de la visita!")
        clearInterval(interval)
      } else {
        // Calcular horas, minutos y segundos
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
        const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))
        const diffSeconds = Math.floor((diffMs % (1000 * 60)) / 1000)

        setTimeLeft(`${diffHours}h ${diffMinutes}m ${diffSeconds}s`)
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [visit])

  if (!visit) return null

  return (
    <div className="modal fade show d-block" tabIndex="-1" role="dialog" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content p-4">
          <div className="modal-header">
            <h5 className="modal-title">Código QR para Visita</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>

          <div className="modal-body text-center">
            <div className="qr-container">
              <QRCodeCanvas value={qrValue} size={250} level="H" includeMargin={true} renderAs="canvas" />
            </div>

            <div className="visit-info mt-3">
              <h6>{visit.visitorName}</h6>
              <p className="mb-1">
                <strong>Fecha:</strong> {formatDate(visit.dateTime)}
              </p>
              <p className="mb-1">
                <strong>Hora:</strong> {formatTime(visit.dateTime)}
              </p>
              <p className="mb-1">
                <strong>Personas:</strong> {visit.numPeople}
              </p>
              <p className="mb-1">
                <strong>Contraseña:</strong> {visit.password}
              </p>

              <div className="time-remaining mt-3">
                <p className="countdown">Tiempo restante: {timeLeft}</p>
              </div>

              <div className="qr-instructions mt-3">
                <p className="text-muted">
                  Este código QR es válido solo hasta 2 horas después de la hora programada. Muéstrelo al guardia para
                  acceder.
                </p>
              </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-primary" onClick={() => window.print()}>
              Imprimir QR
            </button>
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default QRCodeModal

