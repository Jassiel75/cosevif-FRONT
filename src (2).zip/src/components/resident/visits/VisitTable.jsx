"use client"
import { FaEye, FaTrashAlt, FaUserPlus, FaPen } from "react-icons/fa"

function VisitTable({ visits, onView, onUpdate, onToggleStatus, onDelete, onOpenForm }) {
  // Si no hay visitas, mostrar mensaje centrado con botón
  if (!visits || visits.length === 0) {
    return (
      <div className="no-visits">
        <h3>No hay visitas registradas</h3>
        <button className="add-visit-btn" onClick={onOpenForm}>
          <FaUserPlus className="me-2" /> Agregar Visita
        </button>
      </div>
    )
  }

  // Función para formatear la fecha y hora
  const formatDate = (dateTimeStr) => {
    if (!dateTimeStr) return "N/A"
    const date = new Date(dateTimeStr)
    return date.toLocaleDateString("es-MX")
  }

  const formatTime = (dateTimeStr) => {
    if (!dateTimeStr) return "N/A"
    const date = new Date(dateTimeStr)
    return date.toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="table-responsive">
      <table className="table table-bordered text-center align-middle">
        <thead className="table-light" style={{ backgroundColor: "#F2CBB6" }}>
          <tr>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Visitante</th>
            <th>Personas</th>
            <th>Descripción</th>
            <th>Placas</th>
            <th>Contraseña</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {visits.map((visit) => (
            <tr key={visit.id}>
              <td>{formatDate(visit.dateTime)}</td>
              <td>{formatTime(visit.dateTime)}</td>
              <td>{visit.visitorName || "Sin nombre"}</td>
              <td>{visit.numPeople}</td>
              <td>{visit.description}</td>
              <td>{visit.vehiclePlate || "N/A"}</td>
              <td>{visit.password}</td>
              <td>
                <span
                  className={`badge rounded-pill ${
                    visit.status === "PENDING" ? "bg-warning" : visit.status === "IN_PROGRESS" ? "bg-success" : "bg-danger"
                  }`}
                  style={{ cursor: "pointer" }}
                  onClick={() => onToggleStatus(visit)}
                >
                  {visit.status === "PENDING"
                    ? "Pendiente"
                    : visit.status === "IN_PROGRESS"
                    ? "En Progreso"
                    : "Caducada"}
                </span>
              </td>
              <td>
                <div className="justify-content-center" style={{ gap: "8px" }}>
                  <button className="btn btn-info btn-sm" onClick={() => onView(visit)}>
                    <FaEye />
                  </button>
                  <button className="btn btn-primary btn-sm" onClick={() => onUpdate(visit)}>
                    <FaPen />
                  </button>
                  <button className="btn btn-danger btn-sm" onClick={() => onDelete(visit)}>
                    <FaTrashAlt />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default VisitTable
